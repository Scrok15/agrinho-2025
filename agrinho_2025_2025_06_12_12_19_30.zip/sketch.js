// Variáveis para controle de estado e elementos
let modo = 'campo'; // 'campo' ou 'cidade'
let corCeuCampo;
let corCeuCidade;
let imgTrator;
let imgPredio;

function preload() {
  // Pré-carrega imagens se necessário
  // imgTrator = loadImage('assets/trator.png');
  // imgPredio = loadImage('assets/predio.png');
}

function setup() {
  createCanvas(800, 600);
  corCeuCampo = color(135, 206, 235); // Azul claro
  corCeuCidade = color(70, 70, 90); // Cinza escuro
  noStroke(); // Remove contornos padrão
}

function draw() {
  background(220); // Cor de fundo padrão

  // Desenha o céu baseado no modo
  if (modo === 'campo') {
    background(corCeuCampo);
    desenhaCampo();
  } else {
    background(corCeuCidade);
    desenhaCidade();
  }

  // Desenha um elemento que transita entre os dois
  desenhaElementoTransitorio();

  // Texto de instrução
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("Clique para alternar entre Campo e Cidade", width / 2, 30);
}

function desenhaCampo() {
  // Sol ou lua
  fill(255, 255, 0); // Amarelo para o sol
  ellipse(width * 0.8, height * 0.2, 80, 80);

  // Chão
  fill(139, 69, 19); // Marrom
  rect(0, height * 0.7, width, height * 0.3);

  // Árvores simples
  fill(34, 139, 34); // Verde floresta
  triangle(100, height * 0.6, 70, height * 0.75, 130, height * 0.75);
  triangle(200, height * 0.55, 170, height * 0.7, 230, height * 0.7);

  // Rio
  fill(0, 191, 255); // Azul claro para a água
  beginShape();
  vertex(0, height * 0.8);
  bezierVertex(width * 0.2, height * 0.75, width * 0.4, height * 0.85, width, height * 0.8);
  vertex(width, height);
  vertex(0, height);
  endShape(CLOSE);

  // Exemplo de uso de imagem
  // if (imgTrator) {
  //   image(imgTrator, 50, height * 0.6 - imgTrator.height / 2);
  // }
}

function desenhaCidade() {
  // Sol ou lua
  fill(200, 200, 200); // Cinza para a lua ou prédio iluminado
  ellipse(width * 0.8, height * 0.2, 80, 80);

  // Ruas
  fill(50); // Cinza escuro para ruas
  rect(0, height * 0.7, width, height * 0.3);
  fill(200, 200, 0); // Linhas da rua
  rect(width * 0.2, height * 0.85, 50, 5);
  rect(width * 0.4, height * 0.85, 50, 5);
  rect(width * 0.6, height * 0.85, 50, 5);

  // Prédios simples
  fill(150); // Cinza médio para prédios
  rect(50, height * 0.4, 80, height * 0.3);
  rect(150, height * 0.3, 70, height * 0.4);
  rect(250, height * 0.5, 90, height * 0.2);

  // Janelas
  fill(255, 255, 100); // Amarelo claro para janelas acesas
  rect(60, height * 0.45, 15, 15);
  rect(90, height * 0.5, 15, 15);
  rect(160, height * 0.35, 15, 15);

  // Exemplo de uso de imagem
  // if (imgPredio) {
  //   image(imgPredio, 50, height * 0.4 - imgPredio.height / 2);
  // }
}

function desenhaElementoTransitorio() {
  // Exemplo: Um círculo que muda de cor e forma
  let x = mouseX;
  let y = mouseY;
  let tamanho = 50;

  push();
  translate(x, y);

  if (modo === 'campo') {
    // No campo, pode ser uma semente ou fruta
    fill(100, 70, 0); // Marrom para semente
    ellipse(0, 0, tamanho * 0.8, tamanho);
  } else {
    // Na cidade, pode ser uma engrenagem ou roda
    fill(180); // Cinza metálico para engrenagem
    rectMode(CENTER);
    rect(0, 0, tamanho, tamanho * 0.8);
    // Adiciona dentes ou linhas
    for (let i = 0; i < 4; i++) {
      push();
      rotate(PI / 2 * i);
      rect(tamanho / 2 + 5, 0, 10, 20);
      pop();
    }
  }
  pop();
}

function mousePressed() {
  // Alterna o modo ao clicar
  if (modo === 'campo') {
    modo = 'cidade';
  } else {
    modo = 'campo';
  }
}